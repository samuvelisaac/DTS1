import uuid
import logging
import httpx
import json
import re
import time
import os
from typing import Dict, List, Any
from dotenv import load_dotenv
import psycopg2
from datetime import datetime, timezone
import io

load_dotenv()  # Load .env values


# =====================================================
# CONFIG FROM ENV
# =====================================================
API_KEY = os.getenv("AAVA_API_KEY")
USER_EMAIL = os.getenv("USER_EMAIL")
ASYNC_EXECUTE_URL = os.getenv("ASYNC_EXECUTE_URL")
ASYNC_LOG_URL = os.getenv("ASYNC_LOG_URL")
ASYNC_RESULT_URL = os.getenv("ASYNC_RESULT_URL")

KEY_VAULT_NAME = os.getenv("KEY_VAULT_NAME")
TENANT_ID = os.getenv("TENANT_ID")
CLIENT_ID = os.getenv("CLIENT_ID")
CLIENT_SECRET = os.getenv("CLIENT_SECRET")

POSTGRES_CONFIG = {
    "host": os.getenv("POSTGRES_HOST"),
    "port": os.getenv("POSTGRES_PORT"),
    "database": os.getenv("POSTGRES_DB"),
    "user": os.getenv("POSTGRES_USER"),
    "password": os.getenv("POSTGRES_PASSWORD"),
}


PIPELINE_ID = 138
HTTP_TIMEOUT_SECONDS = 300
MAX_RETRIES = 3
RETRY_WAIT_SECONDS = 15

# 👉 SPECIFIC FILE TO PROCESS
FILE_PATH = "P1D/PaymentsOne Funds Movement Worksheet.docx"
CONTAINER_NAME = "fis-forms"


# =====================================================
# LOGGING
# =====================================================
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("fis-standalone")


# =====================================================
# VALIDATION
# =====================================================
def validate_env():
    required = {
        "AAVA_API_KEY": API_KEY,
        "USER_EMAIL": USER_EMAIL,
        "ASYNC_EXECUTE_URL": ASYNC_EXECUTE_URL,
    }

    missing = [k for k, v in required.items() if not v]
    if missing:
        raise ValueError(f"Missing required env variables: {missing}")


# =====================================================
# HTTP CLIENT
# =====================================================
def get_client(api_key: str) -> httpx.Client:
    return httpx.Client(
        headers={
            "access-key": api_key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        timeout=HTTP_TIMEOUT_SECONDS,
    )


# =====================================================
# UTILITIES
# =====================================================
def normalize_raw_output(raw: Any) -> str:
    if raw is None:
        return ""
    txt = json.dumps(raw, indent=2) if isinstance(raw, (dict, list)) else str(raw)
    txt = re.sub(r"```(?:json)?", "", txt, flags=re.I)
    return txt.replace("```", "").strip()


def agent_success(raw_text: str) -> bool:
    t = raw_text.lower()
    return (
        '"status": "success"' in t
        or '"status": "created"' in t
        or '"status": "in progress"' in t
    )

def fetch_async_logs(execution_id: str) -> Dict[str, Any]:
    url = ASYNC_LOG_URL.format(execution_id=execution_id)

    with get_client(API_KEY) as client:
        response = client.get(url)

    if response.status_code >= 400:
        raise RuntimeError("LOG_API_ERROR")

    return response.json()


def fetch_async_result(execution_id: str) -> Dict[str, Any]:
    url = ASYNC_RESULT_URL.format(execution_id=execution_id)

    with get_client(API_KEY) as client:
        response = client.get(url)

    if response.status_code >= 400:
        raise RuntimeError("RESULT_API_ERROR")

    return response.json()

def extract_agent_outputs(result_resp: Dict[str, Any]) -> List[Dict[str, Any]]:
    outputs = []

    result_block = result_resp.get("result", {})
    response_block = result_block.get("response", {})

    if isinstance(response_block, str):
        try:
            response_block = json.loads(response_block)
        except Exception:
            return outputs

    tasks = response_block.get("tasksOutputs", [])

    for t in tasks:
        raw = t.get("raw") or t.get("rawOutput")
        outputs.append({
            "agent_name": t.get("agentName") or t.get("name"),
            "raw_output": normalize_raw_output(raw)
        })

    return outputs

def build_formatted_raw_output(results: List[Dict[str, Any]]) -> str:
    output = io.StringIO()

    output.write(f"WORKFLOW ID : {PIPELINE_ID}\n")
    output.write(f"EXECUTED AT : {datetime.now(timezone.utc).isoformat()}\n")
    output.write("=" * 120 + "\n")

    for r in results:
        success = agent_success(r["raw_output"])

        output.write("\n" + "#" * 120 + "\n")
        output.write(f"AGENT NAME : {r['agent_name']}\n")
        output.write(f"SUCCESS    : {success}\n")
        output.write("-" * 120 + "\n")
        output.write(r["raw_output"] or "EMPTY RAW OUTPUT")
        output.write("\n")

    return output.getvalue()

def insert_application_log(log_text: str, results: List[Dict[str, Any]]):

    formatted_raw = build_formatted_raw_output(results)

    query = """
        INSERT INTO clarity.application_logs
        (
            log_level,
            workflow_id,
            workflow_name,
            message,
            logs,
            raw_output
        )
        VALUES (%s,%s,%s,%s,%s,%s);
    """

    with psycopg2.connect(**POSTGRES_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute(
                query,
                (
                    'INFO',
                    PIPELINE_ID,
                    f"Workflow {PIPELINE_ID}",
                    None,
                    log_text,
                    formatted_raw
                ),
            )
        conn.commit()

# =====================================================
# PIPELINE EXECUTION
# =====================================================
def execute_pipeline(user_inputs: Dict[str, Any], api_key: str) -> Dict[str, Any]:
    """
    Trigger async workflow using multipart form (CORRECT FORMAT)
    """

    form_data = {
        "pipelineId": (None, str(PIPELINE_ID)),
        "userInputs": (None, json.dumps(user_inputs)),  # MUST be string JSON
        "user": (None, USER_EMAIL),
        "priority": (None, "0"),
    }

    logger.info("Executing pipeline id=%s", PIPELINE_ID)
    logger.info("Form Data: %s", form_data)

    with httpx.Client(
        headers={
            "access-key": api_key,
            "Accept": "application/json",
        },
        timeout=HTTP_TIMEOUT_SECONDS,
    ) as client:

        response = client.post(
            ASYNC_EXECUTE_URL,
            files=form_data   # ✅ VERY IMPORTANT
        )

    if response.status_code >= 400:
        logger.error("Pipeline failed: %s %s", response.status_code, response.text)
        raise RuntimeError("PIPELINE_ERROR")

    return response.json()


# =====================================================
# RETRY LOGIC
# =====================================================
def execute_with_retry(user_inputs: Dict[str, Any], api_key: str):

    for attempt in range(1, MAX_RETRIES + 1):
        logger.info("Pipeline attempt %s/%s", attempt, MAX_RETRIES)

        try:
            # 1️⃣ Trigger
            trigger_resp = execute_pipeline(user_inputs, api_key)

            execution_id = (
                trigger_resp.get("workflowExecutionId")
                or trigger_resp.get("executionId")
                or trigger_resp.get("id")
            )

            if not execution_id:
                raise RuntimeError("NO_EXECUTION_ID")

            logger.info("Execution ID: %s", execution_id)

            # 2️⃣ Poll logs
            waited = 0
            max_wait = 600
            poll_interval = 20

            while waited < max_wait:
                logs_resp = fetch_async_logs(execution_id)
                status = logs_resp.get("status", "").upper()

                if status in {"QUEUED", "IN_PROGRESS"}:
                    time.sleep(poll_interval)
                    waited += poll_interval
                    continue

                break

            # 3️⃣ Fetch result
            result_resp = fetch_async_result(execution_id)

            # 4️⃣ Extract raw outputs
            results = extract_agent_outputs(result_resp)

            failed_agents = []
            for r in results:
                if not agent_success(r["raw_output"]):
                    failed_agents.append(r["agent_name"])

            logs_text = json.dumps(logs_resp, indent=2)

            # 5️⃣ Insert into DB
            insert_application_log(logs_text, results)

            if not failed_agents:
                logger.info("Pipeline completed successfully")
                return True

            logger.warning("Failed agents: %s", failed_agents)

        except Exception as e:
            logger.error("Attempt failed: %s", str(e))

        if attempt < MAX_RETRIES:
            time.sleep(RETRY_WAIT_SECONDS)

    logger.error("Pipeline failed after retries")
    return False


# =====================================================
# MAIN
# =====================================================
def main():

    validate_env()

    # 🔐 Directly use API key from .env
    api_key = API_KEY

    # Build Key Vault block only
    Key_Vault_content = (
        f"key_vault_name:{KEY_VAULT_NAME}\n"
        f"tenant_id:{TENANT_ID}\n"
        f"client_id:{CLIENT_ID}\n"
        f"client_secret:{CLIENT_SECRET}"
    )

    # Build File block only
    file_details = (
        f"container_name:{CONTAINER_NAME}\n"
        f"input_blob_name:{FILE_PATH}"
    )

    user_inputs = {
        "{{Key_Vault}}": Key_Vault_content,
        "{{File_path}}": file_details
    }

    logger.info("Starting workflow execution for file: %s", FILE_PATH)

    success = execute_with_retry(user_inputs, api_key)

    if success:
        logger.info("Workflow execution completed successfully ✅")
    else:
        logger.error("Workflow execution failed ❌")


if __name__ == "__main__":
    main()
