import logging
import azure.functions as func
import azure.durable_functions as df
from datetime import datetime

async def main(mytimer: func.TimerRequest, starter: str):

    if mytimer.past_due:
        logging.info("Skipping past due execution")
        return

    client = df.DurableOrchestrationClient(starter)

    # Check if already running
    instances = await client.get_status_all()

    for instance in instances:
        if instance.name == "orchestrator" and instance.runtime_status == "Running":
            logging.info("Orchestrator already running. Skipping new start.")
            return

    instance_id = await client.start_new("orchestrator", None, None)

    logging.info(f"Started orchestration with ID = '{instance_id}'.")
