import io
import os
import logging
import httpx
import json
import re
import time
from datetime import datetime, timezone
from typing import Dict, List, Any
import psycopg2
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
import pandas as pd

# =====================================================
# STATIC CONFIG – CREDENTIALS (REPLACES credential.txt)
# =====================================================
FIS_CONFIG = {
    "key_vault_name": os.getenv("KEY_VAULT_NAME"),
    "tenant_id": os.getenv("TENANT_ID"),
    "azure_client_id": os.getenv("AZURE_CLIENT_ID"),
    "azure_client_secret": os.getenv("AZURE_CLIENT_SECRET"),
}

HTTP_TIMEOUT_SECONDS = 300
MAX_RETRIES = 3
RETRY_WAIT_SECONDS = 15

# =====================================================
# ENV CONFIG
# =====================================================
ASYNC_EXECUTE_URL = os.getenv("ASYNC_EXECUTE_URL")
ASYNC_LOG_URL = os.getenv("ASYNC_LOG_URL")
ASYNC_RESULT_URL = os.getenv("ASYNC_RESULT_URL")

API_URL = os.getenv("AAVA_API_URL")
API_KEY = os.getenv("AAVA_API_KEY")
USER_EMAIL = os.getenv("USER_EMAIL")

POSTGRES_CONFIG = {
    "host": os.getenv("POSTGRES_HOST"),
    "port": os.getenv("POSTGRES_PORT"),
    "database": os.getenv("POSTGRES_DB"),
    "user": os.getenv("POSTGRES_USER"),
    "password": os.getenv("POSTGRES_PASSWORD"),
}

# =====================================================
# LOGGING
# =====================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("aava-pipeline")

# =========================
# SUPPRESS SDK / HTTP LOGS
# =========================
logging.getLogger("azure").setLevel(logging.WARNING)
logging.getLogger("azure.storage").setLevel(logging.WARNING)
logging.getLogger("azure.core.pipeline.policies.http_logging_policy").setLevel(logging.WARNING)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)

# =====================================================
# HTTP CLIENT
# =====================================================
def get_client() -> httpx.Client:
    return httpx.Client(
        headers={
            "access-key": API_KEY,
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        timeout=HTTP_TIMEOUT_SECONDS,
    )


# =====================================================
# UTILITIES
# =====================================================
def normalize_raw_output(raw: Any) -> str:
    if raw is None:
        return ""

    txt = json.dumps(raw, indent=2) if isinstance(raw, (dict, list)) else str(raw)
    txt = re.sub(r"```(?:json)?", "", txt, flags=re.I)
    txt = txt.replace("```", "").strip()

    # REMOVE NON-ASCII CHARACTERS (fix emoji crash)
    txt = txt.encode("ascii", "ignore").decode()

    return txt

# ====================
# AGENT SUCCESS LOGIC
# ====================
def agent_success(workflow_id: int, agent_name: str, raw_text: str) -> bool:
    t = raw_text.lower()

    # =====================================================
    # WORKFLOW 54 LOGIC
    # =====================================================
    if workflow_id == 54:

        # CMI Data Collector
        if agent_name == "CMI Data Collector Agent":
            return '"status": "success"' in t or '"status": "in progress"' in t

        # CMI Data Mapper
        if agent_name == "CMI Data Mapper Agent":
            try:
                data = json.loads(raw_text)
                return bool(data.get("fields")) and "error" not in data
            except Exception:
                return False

        # Form Handler
        if agent_name == "Form Handler (FIS Word & Excel Updater) Agent":
            return '"status": "success"' in t or '"status": "in progress"' in t

        # ServiceNow
        if agent_name == "ServiceNow_Incident_Creator Agent":
            if '**Status:** Failure' in t:
                return False
            elif ('"status": "success"' in t
                or '"status": "created"' in t
                or '"status": "in progress"' in t
                or "all steps were executed and validated with no errors" in t):
                return True
            else:
                return False

        # Blob Attach
        if agent_name == "Blob_File_Attaching Agent":
            if '**Failed**' in t:
                return False
            elif ("step 1:" in t
                and "step 2:" in t
                and (("step 3:" in t
                and "step 4:" in t) or "step 2 & 3:")
                and ('"status": "created"' in t
                    or '"status": "success"' in t
                    or '"status": "in progress"' in t
                    or "status: **success**" in t)):
                return True
            else:
                return False

        # Postgres Logger
        if agent_name == "Postgres_SNOW_Ticket_log Agent":
            return (
                '"status": "success"' in t
                or '"status": "created"' in t
                or '"status": "in progress"' in t
            )

        return False

    # =====================================================
    # WORKFLOW 102 LOGIC
    # =====================================================
    if workflow_id == 102:

        # ServiceNow
        if agent_name == "ServiceNow_Incident_Creator Agent":
            if '**Status:** Failure' in t:
                return False
            elif ('"status": "success"' in t
                or '"status": "created"' in t
                or '"status": "in progress"' in t
                or "all steps were executed and validated with no errors" in t):
                return True
            else:
                return False

        # Blob Attach
        if agent_name == "Blob_File_Attaching Agent":
            if '**Failed**' in t:
                return False
            elif ("step 1:" in t
                and "step 2:" in t
                and (("step 3:" in t
                and "step 4:" in t) or "step 2 & 3:")
                and ('"status": "created"' in t
                    or '"status": "success"' in t
                    or '"status": "in progress"' in t
                    or "status: **success**" in t)):
                return True
            else:
                return False

        # Postgres Logger
        if agent_name == "Postgres_SNOW_Ticket_log Agent":
            return (
                '"status": "success"' in t
                or '"status": "created"' in t
                or '"status": "in progress"' in t
            )

        return False

    # =====================================================
    # DEFAULT — FAIL SAFE
    # =====================================================
    return False


# =====================================================
# FETCH WORKFLOWS (FILE-WISE)
# =====================================================
def fetch_scheduled_workflows() -> List[Dict[str, Any]]:
    query = """
        SELECT jw.file_name,
               jm.scheduled_week,
               jm.job_id,
               jm.client_id,
               jm.client_name,
               jm.sn_ticket_system,
               jw.workflow_id,
               jw.workflow_input
          FROM clarity.job_master jm
          JOIN clarity.job_workflow jw
            ON jm.job_id = jw.job_id
           AND jm.client_name = jw.client_name
         WHERE jm.planned_date::date >= CURRENT_DATE
--           AND jm.action_date::date is null
--           AND jw.workflow_id = 102
           AND jm.scheduled_week = EXTRACT(WEEK FROM CURRENT_DATE)-7
           AND jm.client_id = (select max(client_id) from clarity.job_master)
           AND jw.file_name = '2025_Wave Online Template.xlsx'
         ORDER BY jm.client_id, jm.scheduled_week, CASE WHEN jw.workflow_id = 102 THEN 2 ELSE 1 END, jw.file_name;
    """

    rows = []
    with psycopg2.connect(**POSTGRES_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute(query)
            for (
                file_name,
                scheduled_week,
                job_id,
                job_client_id,
                client_name,
                sn_ticket_system,
                workflow_id,
                workflow_input,
            ) in cur.fetchall():

                rows.append({
                    "file_name": file_name,
                    "scheduled_week": scheduled_week,
                    "job_id": job_id,
                    "job_client_id": job_client_id,
                    "client_name": client_name,
                    "sn_ticket_system": sn_ticket_system,   # ADDED
                    "workflow_id": workflow_id,
                    "workflow_input": workflow_input if isinstance(workflow_input, dict)
                                      else json.loads(workflow_input),
                })

    return rows


def trigger_async_workflow(workflow_id: int, user_inputs: Dict[str, Any]) -> str:
    """
    Triggers async workflow using multipart form
    Returns execution_id
    """

    form_data = {
        "pipelineId": (None, str(workflow_id)),
        "userInputs": (None, json.dumps(user_inputs)),  # STRING JSON
        "user": (None, USER_EMAIL),
        "priority": (None, "0"),
    }

    with httpx.Client(
        headers={
            "access-key": API_KEY,
            "Accept": "application/json"
        },
        timeout=HTTP_TIMEOUT_SECONDS,
    ) as client:

        response = client.post(
            ASYNC_EXECUTE_URL,
            files=form_data   # IMPORTANT
        )

    if response.status_code >= 400:
        logger.error("Trigger failed: %s %s", response.status_code, response.text)
        raise RuntimeError("CLIENT_ERROR")

    data = response.json()

    execution_id = (
        data.get("workflowExecutionId")   # <-- ADD THIS
        or data.get("executionId")
        or data.get("id")
        or data.get("execution_id")
    )

    if not execution_id:
        logger.error("Invalid async trigger response: %s", data)
        raise RuntimeError("INVALID_RESPONSE")

    logger.info("Workflow %s queued with executionId %s", workflow_id, execution_id)
    return execution_id


def fetch_async_logs(execution_id: str) -> Dict[str, Any]:
    url = ASYNC_LOG_URL.format(execution_id=execution_id)

    with get_client() as client:
        response = client.get(url)

    resp_code = response.status_code

    if resp_code >= 400:
        logger.error("LOG_RESP_CODE : %s | STATUS : CLIENT_ERROR", resp_code)
        raise RuntimeError("CLIENT_ERROR")

    data = response.json()
    status = data.get("status", "UNKNOWN").upper()

    if status == "QUEUED":
        logger.info("Workflow queued")
    elif status == "IN_PROGRESS":
        logger.info("Workflow execution in progress...")
    elif status == "SUCCESS":
        logger.info("Workflow execution completed")
    else:
        logger.info("Workflow status: %s", status)

    return data


def extract_agent_raw_outputs(result_resp: Dict[str, Any]) -> List[Dict[str, Any]]:
    outputs = []
    if not result_resp:
        return outputs

    # ---------------------------
    # STEP 1 – get "response"
    # ---------------------------
    result_resp_f = result_resp.get("result", {})
    response_block = result_resp_f.get("response", {})

    # response is STRING JSON → parse it
    if isinstance(response_block, str):
        try:
            response_block = json.loads(response_block)
        except Exception:
            return outputs

    if not isinstance(response_block, dict):
        return outputs

    # ---------------------------
    # STEP 2 – find tasks array
    # ---------------------------
    tasks = response_block.get("tasksOutputs", [])

    if not isinstance(tasks, list):
        return outputs

    # ---------------------------
    # STEP 3 – extract RAW
    # ---------------------------
    for t in tasks:
        raw = t.get("raw", "") or t.get("rawOutput", "")
        
        outputs.append({
            "agentName": t.get("agentName", "") or t.get("name", ""),
            "raw": normalize_raw_output(raw)
        })

    return outputs


def fetch_async_result(execution_id: str) -> Dict[str, Any]:
    url = ASYNC_RESULT_URL.format(execution_id=execution_id)

    with get_client() as client:
        response = client.get(url)

    resp_code = response.status_code

    if resp_code >= 400:
        logger.error("RESULT_RESP_CODE : %s | STATUS : ERROR", resp_code)
        raise RuntimeError(f"RESULT_API_ERROR {resp_code}")

    logger.info("Workflow result received RESULT_RESP_CODE : %s", resp_code)

    return response.json()


# =====================================================
# PIPELINE EXECUTION
# =====================================================
def execute_pipeline_safe(pipeline_id: int, user_inputs: Dict[str, Any]) -> Dict[str, Any]:
    try:
        execution_id = trigger_async_workflow(pipeline_id, user_inputs)

        max_wait_seconds = 600
        poll_interval = 30
        waited = 0

        while waited < max_wait_seconds:
            logs_resp = fetch_async_logs(execution_id)
            status = logs_resp.get("status", "").upper()

            if status in {"QUEUED", "IN_PROGRESS"}:
                time.sleep(poll_interval)
                waited += poll_interval
                continue

            # ===== NEW PART =====
            result_resp = fetch_async_result(execution_id)

            return {
                "logs": logs_resp,
                "result": result_resp
            }

        raise RuntimeError("TIMEOUT")

    except httpx.RequestError as e:
        raise RuntimeError("NETWORK_ERROR")


# =====================================================
# AGENT MAP BASED ON WORKFLOW
# =====================================================
def get_agent_map(workflow_id: int) -> Dict[int, str]:

    if workflow_id == 54:
        return {
            1: "CMI Data Collector Agent",
            2: "CMI Data Mapper Agent",
            3: "Form Handler (FIS Word & Excel Updater) Agent",
            4: "ServiceNow_Incident_Creator Agent",
            5: "Blob_File_Attaching Agent",
            6: "Postgres_SNOW_Ticket_log Agent",
        }

    if workflow_id == 102:
        return {
            1: "ServiceNow_Incident_Creator Agent",
            2: "Blob_File_Attaching Agent",
            3: "Postgres_SNOW_Ticket_log Agent",
        }

    # DEFAULT FALLBACK
    return {}


# =====================================================
# PARSE RESULTS
# =====================================================
def parse_pipeline_results(resp: Dict[str, Any], workflow_id: int):
    result_section = resp.get("result", {})

    if not result_section:
        result_section = resp.get("result", {}).get("result", {})

    raw_agents = extract_agent_raw_outputs(result_section)

    if not raw_agents:
        logger.warning("No agent RAW outputs found in RESULT API")

    results = []
    agent_map = get_agent_map(workflow_id)

    for idx, agent in enumerate(raw_agents, start=1):
        agent_name = agent_map.get(idx, agent.get("agentName", f"Agent{idx}"))

        raw = agent.get("raw", "")

        results.append({
            "agent_name": agent_name,
            "success": agent_success(workflow_id, agent_name, raw),
            "raw_output": raw
        })

    if not raw_agents:
        results = resp

    return results


def format_logs_as_text(resp):
    if not isinstance(resp, dict):
        return ""

    rows = resp.get("workflowExecutionLogs", [])
    lines = []

    for row in rows:
        raw = row.get("logs", "")
        if not raw:
            continue

        try:
            inner = json.loads(raw)   # string → dict
            content = inner.get("content", "")

            # remove ANSI escape color codes
            content = re.sub(r'\x1b\[[0-9;]*m', '', content)

            if content.strip():
                lines.append(content.strip())

        except Exception as e:
            print("PARSE ERROR:", e)
            continue

    return "\n".join(lines)


# =====================================================
# RETRY LOGIC
# =====================================================
def execute_with_retry(pipeline_id: int, user_inputs: Dict[str, Any], wf: Dict[str, Any]):
    last_results: List[Dict[str, Any]] = []
    last_resp: Dict[str, Any] = {}

    for attempt in range(1, MAX_RETRIES + 1):
        logger.info("Week %s | File %s | Pipeline %s | Attempt %s", wf["scheduled_week"], wf["file_name"], pipeline_id, attempt)

        try:
            resp = execute_pipeline_safe(pipeline_id, user_inputs)
            last_resp = resp

            results = parse_pipeline_results(resp, pipeline_id)
            last_results = results

            failed = [r["agent_name"] for r in results if not r["success"]]
            if not failed:
                logger.info("Week %s | File %s | Pipeline %s succeeded on attempt %s", wf["scheduled_week"], wf["file_name"], pipeline_id, attempt)
                text_logs = format_logs_as_text(last_resp.get("logs"))
                return last_results, text_logs

            logger.warning(
                "Attempt %s completed with FAILED agents: %s",
                attempt,
                ", ".join(failed),
            )

        except RuntimeError as e:
            err = str(e)

            if err in {"SERVER_ERROR", "NETWORK_ERROR"}:
                logger.warning(
                    "Retryable error on attempt %s for pipeline %s (%s)",
                    attempt,
                    pipeline_id,
                    err,
                )
            else:
                logger.error(
                    "Non-retryable error for pipeline %s: %s",
                    pipeline_id,
                    err,
                )
                break

        if attempt < MAX_RETRIES:
            logger.info("Waiting %s seconds before retry...", RETRY_WAIT_SECONDS)
            time.sleep(RETRY_WAIT_SECONDS)

    logger.error("Pipeline %s failed after %s attempts", pipeline_id, MAX_RETRIES)
    text_logs = format_logs_as_text(last_resp.get("logs"))

    return last_results, text_logs


# =====================================================
# ENSURE OUTPUT BLOB PATH WITH CLIENT FOLDER
# =====================================================
def prepare_output_blob_path(
    container_name: str,
    raw_output_path: str,
    job_client_id: int
) -> str:
    """
    1. Replace <client_id> with actual job_client_id
    2. Skip folder creation if path contains 'SN_TICKET'
    3. Create folder using .init blob otherwise
    """

    if not raw_output_path:
        return raw_output_path

    conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    blob_service = BlobServiceClient.from_connection_string(conn_str)
    container_client = blob_service.get_container_client(container_name)

    updated_paths = []

    # Support comma separated blob paths
    paths = [p.strip() for p in raw_output_path.split(",") if p.strip()]

    for path in paths:

        # ----------------------------
        # 1. Replace <client_id>
        # ----------------------------
        updated_path = path.replace("<client_id>", str(job_client_id))

        # ------------------------------------------------
        # 2. Skip folder creation for SN_TICKET paths
        # ------------------------------------------------
        if "SN_TICKET" in updated_path.upper():
            updated_paths.append(updated_path)
            continue

        # ------------------------------------------
        # 3. Create folder via .init dummy blob
        # ------------------------------------------
        folder_path = "/".join(updated_path.split("/")[:-1])

        if folder_path:
            dummy_blob_path = f"{folder_path}/.init"
            blob_client = container_client.get_blob_client(dummy_blob_path)

            if not blob_client.exists():
                blob_client.upload_blob(b"", overwrite=True)
                logger.info("Created folder structure: %s", folder_path)

        updated_paths.append(updated_path)

    return ",".join(updated_paths)


# =====================================================
# LOAD BLOB MAPPING FROM POSTGRES
# =====================================================
def get_blob_details_by_file(
    file_name: str,
    job_client_id: int,
    sn_ticket_system: str
) -> Dict[str, str]:

    query = """
        SELECT
            container_name,
            input_blob_path,
            output_blob_path
        FROM clarity.io_blob_file_path
        WHERE mapped_template_file = %s
          AND (
              sn_ticket_system = ''
              OR LOWER(sn_ticket_system) = LOWER(%s)
          )
        ORDER BY
            CASE WHEN sn_ticket_system IS NULL THEN 2 ELSE 1 END
        LIMIT 1;
    """

    with psycopg2.connect(**POSTGRES_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute(query, (file_name, sn_ticket_system))
            row = cur.fetchone()

    if not row:
        logger.warning(
            "No blob mapping found for file=%s sn_ticket_system=%s",
            file_name,
            sn_ticket_system
        )
        return {}

    container_name = row[0]
    input_blob = row[1]
    output_blob_raw = row[2]

    # Apply client id replacement + folder creation
    output_blob_final = prepare_output_blob_path(
        container_name,
        output_blob_raw,
        job_client_id
    )

    return {
        "container_name": container_name,
        "input_blob_name": input_blob,
        "output_blob_name": output_blob_final,
    }


def build_dynamic_placeholders(
    file_name: str,
    job_client_id: int,
    sn_ticket_system: str
):

    blob_details = get_blob_details_by_file(
        file_name,
        job_client_id,
        sn_ticket_system
    )

    # SAFE DEFAULTS
    file_details_value = ""
    ticket_details_value = ""

    # =========================
    # KEY VAULT STRING
    # =========================

    key_vault_value = f"""key_vault_name:{FIS_CONFIG['key_vault_name']}
tenant_id:{FIS_CONFIG['tenant_id']}
client_id:{FIS_CONFIG['azure_client_id']}
client_secret:{FIS_CONFIG['azure_client_secret']}"""

    if blob_details:
        key_vault_value = f"""key_vault_name:{FIS_CONFIG['key_vault_name']}
tenant_id:{FIS_CONFIG['tenant_id']}
client_id:{FIS_CONFIG['azure_client_id']}
client_secret:{FIS_CONFIG['azure_client_secret']}
container_name:{blob_details['container_name']}
input_blob_name:{blob_details['input_blob_name']}
output_blob_name:{blob_details['output_blob_name']}"""

    if blob_details:
        raw_paths = blob_details["output_blob_name"]
    
        # SPLIT COMMA SEPARATED FILES INTO CLEAN LIST
        if raw_paths and "," in raw_paths:
            blob_list = [p.strip() for p in raw_paths.split(",") if p.strip()]
            formatted_paths = json.dumps(blob_list)  # pass as JSON array
        else:
            formatted_paths = raw_paths.strip()
    
        file_details_value = f"""container_name: {blob_details['container_name']}
blob_file_path: {formatted_paths}"""

    # =========================
    # DEFAULT TICKET DETAILS
    # =========================
    ticket_details_value = ""

    if not blob_details or not sn_ticket_system:
        return key_vault_value, file_details_value, ticket_details_value

    try:
        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        blob_service = BlobServiceClient.from_connection_string(conn_str)

        blob_client = blob_service.get_blob_client(
            container=blob_details["container_name"],
            blob="forms/output/Servicenow_Incident_Mapping.xlsx"
        )

        data = blob_client.download_blob().readall()

        # ==============================
        # LOAD EXCEL WITH ALL SHEETS
        # ==============================
        excel_file = pd.ExcelFile(io.BytesIO(data))

        if sn_ticket_system not in excel_file.sheet_names:
#            logger.warning("Sheet %s not found in mapping file", sn_ticket_system)
#            return key_vault_value, file_details_value, ticket_details_value
            # ==============================
            # READ ONLY MATCHING SHEET
            # ==============================
            df = pd.read_excel(
                excel_file,
                sheet_name="Go-Live"
            )
        else:
            # ==============================
            # READ ONLY MATCHING SHEET
            # ==============================
            df = pd.read_excel(
                excel_file,
                sheet_name=sn_ticket_system
            )

        logger.info("Loaded sheet %s successfully", sn_ticket_system)

        if "Target Field" not in df.columns:
            logger.warning("Target Field column missing in sheet %s", sn_ticket_system)
            return key_vault_value, file_details_value, ticket_details_value

        target_fields = df["Target Field"].dropna().tolist()

        if not target_fields:
            return key_vault_value, file_details_value, ticket_details_value

        # ==============================
        # BUILD DYNAMIC QUERY
        # ==============================
        cols = ",".join(target_fields)

        query = f"""
            SELECT {cols}
            FROM clarity.incident_ticket_details
            WHERE client_id = %s
            LIMIT 1;
        """

        with psycopg2.connect(**POSTGRES_CONFIG) as conn:
            with conn.cursor() as cur:
                cur.execute(query, (job_client_id,))
                row = cur.fetchone()

        if row:
            ticket_details_value = "\n".join(
                f"{col}: {val}"
                for col, val in zip(target_fields, row)
                if val is not None and str(val).strip() != ""
            )

    except Exception as e:
        logger.error("Error building ticket details: %s", repr(e))

    return key_vault_value, file_details_value, ticket_details_value


# =====================================================
# BUILD USER INPUTS (UPDATED – NO FILE READ)
# =====================================================
def build_user_inputs(wf: Dict[str, Any]) -> Dict[str, Any]:

    base_inputs = dict(wf["workflow_input"])
    file_name = wf["file_name"]
    job_client_id = wf["job_client_id"]

    kv, file_det, ticket_det = build_dynamic_placeholders(
        file_name,
        job_client_id,
        wf.get("sn_ticket_system")
    )

    base_inputs["{{Key_Vault}}"] = kv

    base_inputs["{{file_details}}"] = file_det

    base_inputs["{{ticket_details}}"] = ticket_det

    return base_inputs


# =====================================================
# BUILD FORMATTED RAW OUTPUT (EXACT WRITE_OUTPUT FORMAT)
# =====================================================
def build_formatted_raw_output(
    pipeline_id: int,
    file_name: str,
    results: List[Dict[str, Any]]
) -> str:

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

    output = io.StringIO()

    output.write(f"FILE NAME   : {file_name}\n")
    output.write(f"WORKFLOW ID : {pipeline_id}\n")
    output.write(f"EXECUTED AT : {datetime.now(timezone.utc).isoformat()}\n")
    output.write(f"TOTAL AGENTS: {len(results)}\n")
    output.write("=" * 120 + "\n")

    if not results:
        output.write("\nNO AGENT OUTPUTS RETURNED FROM RESULT API\n")
    else:
        for r in results:
            output.write("\n" + "#" * 120 + "\n")
            output.write(f"AGENT NAME : {r['agent_name']}\n")
            output.write(f"SUCCESS    : {r['success']}\n")
            output.write("-" * 120 + "\n")
            output.write("RAW OUTPUT:\n")
            output.write(r["raw_output"] or "EMPTY RAW OUTPUT")
            output.write("\n")

    return output.getvalue()


# =========================
# SANITIZING OR MASKING LOG
# =========================
def sanitize_logs(raw_logs_text: str) -> str:

    secret_fields = [
        "host",
        "port",
        "database",
        "user",
        "password",
        "mappingdirectory",
        "storageaccount",
        "filesystem",
        "accesskey",
        "mappingfile",
        "formdirectory",
        "servicenow-url",
        "sn-username",
        "sn-password",
        "connectionstring"
    ]

    for field in secret_fields:

        pattern = rf"{field}\s*[:=]\s*['\"]?.+?['\"]?"

        raw_logs_text = re.sub(
            pattern,
            f"{field}: *****",
            raw_logs_text,
            flags=re.IGNORECASE
        )

    return raw_logs_text


# =====================================================
# APPLICATION LOG INSERT (FINAL)
# =====================================================
def insert_application_log(
    wf: Dict[str, Any],
    raw_logs_text: str,
    results: List[Dict[str, Any]]
) -> int:
    workflow_id = wf["workflow_id"]

    WORKFLOW_NAME_MAP = {
        54: "Workflow 54",
        102: "Workflow 102",
        213: "Workflow 213",
    }

    workflow_name = WORKFLOW_NAME_MAP.get(workflow_id, f"Workflow {workflow_id}")

    formatted_raw_output = build_formatted_raw_output(
        workflow_id,
        wf.get("file_name", ""),
        results
    )

    query = """
        INSERT INTO clarity.application_logs
        (
            log_level,
            workflow_id,
            workflow_name,
            client_id,
            client_name,
            job_id,
            file_name,
            message,
            logs,
            raw_output
        )
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        RETURNING log_id;
    """

    try:
        with psycopg2.connect(**POSTGRES_CONFIG) as conn:
            with conn.cursor() as cur:

                cur.execute(
                    query,
                    (
                        'INFO',
                        workflow_id,
                        workflow_name,
                        wf.get("job_client_id", 0),
                        wf.get("client_name", ""),
                        wf.get("job_id", 0),
                        wf.get("file_name", ""),
                        None,
                        sanitize_logs(raw_logs_text),
                        formatted_raw_output
                    ),
                )

                log_id = cur.fetchone()[0]

            conn.commit()

        logger.info("Inserted application_logs row with log_id %s", log_id)

        return log_id

    except Exception as e:
        logger.error("Failed to insert application log: %s", repr(e))
        return None


def trigger_workflow_213_for_log(log_id: int):

    if not log_id:
        logger.error("Invalid log_id. Skipping Workflow 213 trigger.")
        return

    try:

        # ================================
        # BUILD FULL KEY VAULT STRING
        # ================================
        key_vault_name = FIS_CONFIG.get("key_vault_name")
        tenant_id = FIS_CONFIG.get("tenant_id")
        client_id = FIS_CONFIG.get("azure_client_id")
        client_secret = FIS_CONFIG.get("azure_client_secret")

        # Validate values
        if not all([key_vault_name, tenant_id, client_id, client_secret]):
            raise RuntimeError(
                f"Key Vault ENV variables missing: "
                f"key_vault_name={key_vault_name}, "
                f"tenant_id={tenant_id}, "
                f"client_id={client_id}, "
                f"client_secret={'SET' if client_secret else 'MISSING'}"
            )

        key_vault_value = "\n".join([
            f"key_vault_name:{key_vault_name}",
            f"tenant_id:{tenant_id}",
            f"client_id:{client_id}",
            f"client_secret:{client_secret}"
        ])

        user_inputs = {
            "{{logID}}": str(log_id),
            "{{Key_Vault}}": key_vault_value
        }

        logger.info(
            "Triggering Workflow 213 for log_id=%s using KeyVault=%s",
            log_id,
            key_vault_name
        )

        # ================================
        # TRIGGER WORKFLOW 213
        # ================================
        execution_id = trigger_async_workflow(213, user_inputs)

        logger.info(
            "Workflow 213 triggered successfully | execution_id=%s",
            execution_id
        )

        # ================================
        # POLL STATUS
        # ================================
        max_wait_seconds = 320
        poll_interval = 60
        waited = 0

        while waited < max_wait_seconds:

            logs_resp = fetch_async_logs(execution_id)
            status = logs_resp.get("status", "").upper()

            if status == "QUEUED":
                logger.info("Workflow 213 status: QUEUED")

            elif status == "IN_PROGRESS":
                logger.info("Workflow 213 status: IN_PROGRESS")

            elif status == "SUCCESS":
                logger.info(
                    "Workflow 213 completed successfully for log_id=%s",
                    log_id
                )
                return

            elif status in {"FAILED", "ERROR"}:
                logger.error(
                    "Workflow 213 FAILED for log_id=%s",
                    log_id
                )
                return

            time.sleep(poll_interval)
            waited += poll_interval

        logger.warning(
            "Workflow 213 polling timeout reached for log_id=%s",
            log_id
        )

    except Exception as e:
        logger.error(
            "Error while triggering Workflow 213 for log_id=%s : %s",
            log_id,
            repr(e)
        )


# =====================================================
# UPDATE JOB MASTER ACTION DATE
# =====================================================
def update_job_action_date(job_id: int):
    """
    Updates clarity.job_master.action_date to CURRENT_TIMESTAMP
    for the completed job_id.
    """

    query = """
        UPDATE clarity.job_master
           SET action_date = CURRENT_TIMESTAMP
         WHERE job_id = %s
           AND action_date IS NULL;
    """

    try:
        with psycopg2.connect(**POSTGRES_CONFIG) as conn:
            with conn.cursor() as cur:
                cur.execute(query, (job_id,))
            conn.commit()

        logger.info("Updated action_date for job_id %s", job_id)

    except Exception as e:
        logger.error("Failed to update action_date for job_id %s: %s",
                     job_id, repr(e))

def cleanup_init_files(container_name: str, job_client_id: int):
    """
    Delete all .init files inside client subfolders
    """

    try:
        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        blob_service = BlobServiceClient.from_connection_string(conn_str)
        container_client = blob_service.get_container_client(container_name)

        prefix = f"forms/{job_client_id}/"

        blobs = container_client.list_blobs(name_starts_with=prefix)

        for blob in blobs:
            if blob.name.endswith("/.init"):
                container_client.delete_blob(blob.name)
                logger.info("Deleted init file: %s", blob.name)

    except Exception as e:
        logger.error("Error deleting .init files: %s", repr(e))

# =====================================================
# MAIN BUSINESS LOGIC CHANGE ONLY
# =====================================================
def main(name: dict):
    log_stream = io.StringIO()
    handler = logging.StreamHandler(log_stream)
    root_logger = logging.getLogger()
    root_logger.addHandler(handler)
    root_logger.setLevel(logging.INFO)

    try:
        root_logger.info("Pipeline started")

        # ================= DB TIME CHECK =================
        with psycopg2.connect(**POSTGRES_CONFIG) as conn:
            with conn.cursor() as cursor:

                cursor.execute("""
				    SELECT MAX(time_of_day) as time_of_day
                      FROM clarity.job_master
                     WHERE planned_date::date = CURRENT_DATE
--                       and action_date::date is null
					   and scheduled_week = EXTRACT(WEEK FROM CURRENT_DATE)-7
                       AND client_id = (select max(client_id) from clarity.job_master)
                       """)

                row = cursor.fetchone()

                if row:
                    db_time = row[0]
                    current_time = datetime.now().time()

                    root_logger.info(f"DB Time: {db_time}")
                    root_logger.info(f"Current Time: {current_time}")

                    if not db_time or current_time < db_time:
                        root_logger.info("Skipped due to time mismatch")
                        return log_stream.getvalue()

                else:
                    root_logger.info("No workflows found")
                    return log_stream.getvalue()


        root_logger.info("Executing main business logic...")

# ===================================================================
#                       MAIN BUSINESS LOGIC
# ===================================================================

        workflows = fetch_scheduled_workflows()

        if not workflows:
            root_logger.info("No workflows found")
            return log_stream.getvalue()

        processed_jobs = set()

        for wf in workflows:
            file_name = wf["file_name"]
            workflow_id = wf["workflow_id"]
            job_id = wf["job_id"]

            root_logger.info("Executing Week %s | File %s | pipeline=%s | job_id=%s",
                             wf["scheduled_week"], file_name, workflow_id, job_id)

            # ---------- BUILD USER INPUTS ----------
            user_inputs = build_user_inputs(wf)

            # ---------- EXECUTE ----------
            results, logs_text = execute_with_retry(workflow_id, user_inputs, wf)

            # ---------- LOG INSERT ----------
            log_id = insert_application_log(wf, logs_text, results)

            # Trigger Workflow 102 immediately after log insert
            trigger_workflow_213_for_log(log_id)

            # Track processed job_id
            processed_jobs.add(job_id)

        # =====================================================
        # UPDATE ACTION_DATE AFTER ALL FILES COMPLETED
        # =====================================================
        for job_id in processed_jobs:
            update_job_action_date(job_id)

        # ==========================================
        # CLEANUP .init FILES AFTER PROCESSING
        # ==========================================
        containers_cleaned = set()
        
        for wf in workflows:
            file_name = wf["file_name"]
            job_client_id = wf["job_client_id"]
            sn_ticket_system = wf.get("sn_ticket_system")
        
            blob_details = get_blob_details_by_file(
                file_name,
                job_client_id,
                sn_ticket_system
            )

            if not blob_details:
                logger.warning("Skipping file due to missing blob mapping")
                continue

            container_name = blob_details.get("container_name")
            if container_name and container_name not in containers_cleaned:
                cleanup_init_files(container_name, job_client_id)
                containers_cleaned.add(container_name)

        root_logger.info("All workflows executed file-wise")
        root_logger.info("Pipeline completed")

    except Exception as e:
        root_logger.error(str(e))

    return log_stream.getvalue()
